package jretana.fandbui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FanDbuiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FanDbuiApplication.class, args);
	}

}
